﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Parcial4_PROGRA2.Models;
using System.Web.Mvc;

namespace Parcial4_PROGRA2.Controllers
{
    public class CompraController : Controller
    {
        // GET: Compra
        public ActionResult Compras()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Compras(Variables ob)
        {
            double total;
            double descuento=0;
            double totalC;
            total = ob.articulos * ob.precio;

            if (total > 100000)
            {
                descuento = total * 0.20;
            }
            totalC = (total - descuento);
            ViewBag.descuento = descuento;
            ViewBag.totalC = totalC;


            return View(ob);
        }
    }
}