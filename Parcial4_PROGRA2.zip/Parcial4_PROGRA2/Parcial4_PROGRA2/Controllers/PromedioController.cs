﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Parcial4_PROGRA2.Models;
using System.Web.Mvc;


namespace Parcial4_PROGRA2.Controllers
{
    public class PromedioController : Controller
    {
        // GET: Promedio
        public ActionResult Calculo()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public ActionResult Calculo(Estudiante obC)
        {
            double promedio = (obC.nota1 + obC.nota2 + obC.nota3) / 3;
            if (promedio >=7)
            {
               
                ViewBag.promedio = promedio;
                ViewBag.mesage = "Felicidades aprobo la materia";
            }
            if (promedio < 7)
            {
                
                ViewBag.promedio = promedio;
                ViewBag.mesage = "Reprobo la materia";
            }
           
            return View(obC);
        }
        
    }
}