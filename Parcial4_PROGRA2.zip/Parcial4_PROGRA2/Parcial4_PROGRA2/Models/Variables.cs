﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial4_PROGRA2.Models
{
    public class Variables
    {
        public double precio { get; set; }
        public int articulos { get; set; }
    }
}