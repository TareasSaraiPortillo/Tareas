﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial4_PROGRA2.Models
{
    public class Estudiante
    {
       public string codigo { get; set; }
        public string estudiante { get; set; }
        public string materia { get; set; }
        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
        
    }
}