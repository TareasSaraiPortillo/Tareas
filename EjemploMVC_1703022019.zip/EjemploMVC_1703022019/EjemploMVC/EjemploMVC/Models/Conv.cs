﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EjemploMVC.Models
{
    public class Conv
    {
        public double num1 { get; set; }
        
        
    }
}