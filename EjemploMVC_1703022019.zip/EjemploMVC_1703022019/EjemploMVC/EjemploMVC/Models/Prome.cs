﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EjemploMVC.Models
{
    public class Prome
    {
        public double Nota1 { get; set; }
        public double Nota2 { get; set; }
        public double Nota3 { get; set; }
    }
}