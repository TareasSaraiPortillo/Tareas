﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploMVC.Models;

namespace EjemploMVC.Controllers
{
    public class PruebaController : Controller
    {
        // GET: Prueba
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Calculo obCalculo)
        {
            int resultado = obCalculo.numero1 + obCalculo.numero2;
            int resta = obCalculo.numero1 - obCalculo.numero2;
            int multi= obCalculo.numero1 * obCalculo.numero2;
            int divi =obCalculo.numero1 / obCalculo.numero2;
            ViewBag.resultado = resultado;
            ViewBag.resta = resta;
            ViewBag.multi = multi;
            ViewBag.divi = divi;
            return View(obCalculo);
        }


    }
}