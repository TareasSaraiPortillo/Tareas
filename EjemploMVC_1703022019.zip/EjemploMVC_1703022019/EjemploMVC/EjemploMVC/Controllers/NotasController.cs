﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploMVC.Models;


namespace EjemploMVC.Controllers
{
    public class NotasController : Controller
    {
        // GET: Notas
        public ActionResult Promedio()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Promedio(Prome obConvert)
        {
            double promedio = (obConvert.Nota1 + obConvert.Nota2 + obConvert.Nota3)/3;
            if (promedio == 10)
            {
                ViewBag.promedio = promedio;
                ViewBag.mesage = "Felicidades su promedio fue excelente";
            }
            else if(promedio <10 && promedio >= 7)
            {
                ViewBag.promedio = promedio;
                ViewBag.mesage = "Aprobo la materia";
            }
            else if (promedio < 7 && promedio>=4)
            {
                ViewBag.promedio = promedio;
                ViewBag.mesage = "Reprobo la materia";

            }
            else if (promedio < 4)
            {
                ViewBag.promedio = promedio;
                ViewBag.mesage = "Promedio demasiado bajo contacte a su tutor";
            }
            return View(obConvert);


        }
    }
}