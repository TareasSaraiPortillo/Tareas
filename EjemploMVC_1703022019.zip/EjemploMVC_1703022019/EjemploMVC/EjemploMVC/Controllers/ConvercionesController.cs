﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploMVC.Models;

namespace EjemploMVC.Controllers
{
    public class ConvercionesController : Controller
    {
       
        // GET: Converciones
        public ActionResult Converciones()
        {
            return View();
        }
        

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Converciones(Conv obConvert)
        {
           
           double Kelvin = obConvert.num1 + 273.15;
           double celsios = obConvert.num1 - 273.15;

            double KG = obConvert.num1 / 2.205;
            double LB = obConvert.num1 * 2.205;

            double PG = obConvert.num1* 39.37;
            double MT = obConvert.num1 / 39.37;

            ViewBag.Kelvin = Kelvin;
            ViewBag.celsios = celsios;
            ViewBag.KG = KG;
            ViewBag.LB = LB;
            ViewBag.PG = PG;
            ViewBag.MT = MT;

            return View(obConvert);
        }
    }
}